import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve, precision_recall_curve, average_precision_score
import seaborn as sns

# Load both models for comparison
original_model = joblib.load('oral_cancer_model.pkl')
improved_model = joblib.load('improved_oral_cancer_model.pkl')
test_data = pd.read_csv('test_set.csv')

# Separate features and target
X_test = test_data.drop('Oral Cancer (Diagnosis)', axis=1)
y_test = test_data['Oral Cancer (Diagnosis)']

# Make predictions with both models
original_pred = original_model.predict(X_test)
original_pred_proba = original_model.predict_proba(X_test)[:, 1]

improved_pred = improved_model.predict(X_test)
improved_pred_proba = improved_model.predict_proba(X_test)[:, 1]

# Calculate metrics for both models
original_accuracy = (original_pred == y_test).mean()
original_roc_auc = roc_auc_score(y_test, original_pred_proba)

improved_accuracy = (improved_pred == y_test).mean()
improved_roc_auc = roc_auc_score(y_test, improved_pred_proba)

# Print comparison results
print("\nModel Comparison on Test Set:")
print("==================================")
print(f"Original Model Accuracy: {original_accuracy:.4f}")
print(f"Improved Model Accuracy: {improved_accuracy:.4f}")
print(f"Accuracy Improvement: {(improved_accuracy - original_accuracy) * 100:.2f}%")
print("\n")
print(f"Original Model ROC AUC: {original_roc_auc:.4f}")
print(f"Improved Model ROC AUC: {improved_roc_auc:.4f}")
print(f"ROC AUC Improvement: {(improved_roc_auc - original_roc_auc) * 100:.2f}%")

# Print detailed classification reports
print("\nOriginal Model Classification Report:")
print(classification_report(y_test, original_pred))
print("\nImproved Model Classification Report:")
print(classification_report(y_test, improved_pred))

# Print confusion matrices
print("\nOriginal Model Confusion Matrix:")
print(confusion_matrix(y_test, original_pred))
print("\nImproved Model Confusion Matrix:")
print(confusion_matrix(y_test, improved_pred))

# Plot ROC curves for comparison
plt.figure(figsize=(10, 8))

# Original model ROC
fpr_orig, tpr_orig, _ = roc_curve(y_test, original_pred_proba, pos_label='Yes')
plt.plot(fpr_orig, tpr_orig, label=f'Original Model (AUC = {original_roc_auc:.4f})', linestyle='--')

# Improved model ROC
fpr_impr, tpr_impr, _ = roc_curve(y_test, improved_pred_proba, pos_label='Yes')
plt.plot(fpr_impr, tpr_impr, label=f'Improved Model (AUC = {improved_roc_auc:.4f})')

# Reference line
plt.plot([0, 1], [0, 1], 'k--', alpha=0.3)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve Comparison')
plt.legend(loc='lower right')
plt.grid(alpha=0.3)
plt.savefig('roc_comparison.png')
plt.close()

# Plot Precision-Recall curves for comparison
plt.figure(figsize=(10, 8))

# Original model PR curve
precision_orig, recall_orig, _ = precision_recall_curve(y_test, original_pred_proba, pos_label='Yes')
avg_precision_orig = average_precision_score(y_test == 'Yes', original_pred_proba)
plt.plot(recall_orig, precision_orig, label=f'Original Model (AP = {avg_precision_orig:.4f})', linestyle='--')

# Improved model PR curve
precision_impr, recall_impr, _ = precision_recall_curve(y_test, improved_pred_proba, pos_label='Yes')
avg_precision_impr = average_precision_score(y_test == 'Yes', improved_pred_proba)
plt.plot(recall_impr, precision_impr, label=f'Improved Model (AP = {avg_precision_impr:.4f})')

# Reference line for balanced classes
plt.axhline(y=sum(y_test == 'Yes')/len(y_test), color='r', linestyle=':', alpha=0.3, label='Baseline')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve Comparison')
plt.legend(loc='lower left')
plt.grid(alpha=0.3)
plt.savefig('pr_comparison.png')
plt.close()

# Plot confusion matrices side by side
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))

# Original model confusion matrix
sns.heatmap(confusion_matrix(y_test, original_pred), annot=True, fmt='d', cmap='Blues', ax=ax1)
ax1.set_title('Original Model Confusion Matrix')
ax1.set_xlabel('Predicted')
ax1.set_ylabel('Actual')

# Improved model confusion matrix
sns.heatmap(confusion_matrix(y_test, improved_pred), annot=True, fmt='d', cmap='Blues', ax=ax2)
ax2.set_title('Improved Model Confusion Matrix')
ax2.set_xlabel('Predicted')
ax2.set_ylabel('Actual')

plt.tight_layout()
plt.savefig('confusion_matrix_comparison.png')
plt.close()

# Print class distribution
print("\nClass Distribution in Test Set:")
print(y_test.value_counts(normalize=True))

# Calculate and print additional metrics
from sklearn.metrics import precision_score, recall_score, f1_score

print("\nDetailed Metrics Comparison:")
print("==================================")
print(f"Original Model Precision: {precision_score(y_test, original_pred, pos_label='Yes'):.4f}")
print(f"Improved Model Precision: {precision_score(y_test, improved_pred, pos_label='Yes'):.4f}")
print("\n")
print(f"Original Model Recall: {recall_score(y_test, original_pred, pos_label='Yes'):.4f}")
print(f"Improved Model Recall: {recall_score(y_test, improved_pred, pos_label='Yes'):.4f}")
print("\n")
print(f"Original Model F1 Score: {f1_score(y_test, original_pred, pos_label='Yes'):.4f}")
print(f"Improved Model F1 Score: {f1_score(y_test, improved_pred, pos_label='Yes'):.4f}")