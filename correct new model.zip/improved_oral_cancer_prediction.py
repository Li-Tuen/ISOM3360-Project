import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score, precision_recall_curve, average_precision_score
from sklearn.feature_selection import SelectFromModel, RFE
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
import matplotlib.pyplot as plt
import seaborn as sns
import sys
from io import StringIO
import joblib

# Redirect print output to both console and file
class Logger:
    def __init__(self, filename="improved_model_results.txt"):
        self.terminal = sys.stdout
        self.log = open(filename, "w")
   
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()
        
    def flush(self):
        self.terminal.flush()
        self.log.flush()

sys.stdout = Logger()

# Load the dataset
df = pd.read_csv('oral_cancer_prediction_dataset.csv')
print(f"Dataset loaded with {df.shape[0]} rows and {df.shape[1]} columns")

# Check class distribution
class_dist = df['Oral Cancer (Diagnosis)'].value_counts(normalize=True)
print("\nClass Distribution in Full Dataset:")
print(class_dist)

# Define post-diagnosis features to exclude
post_diagnosis_features = [
    'Tumor Size (cm)',
    'Cancer Stage',
    'Treatment Type',
    'Survival Rate (5-Year, %)',
    'Cost of Treatment (USD)',
    'Economic Burden (Lost Workdays per Year)'
]

# Data preprocessing
# Convert categorical variables to numerical
categorical_columns = ['Gender', 'Tobacco Use', 'Alcohol Consumption', 'HPV Infection', 
                      'Betel Quid Use', 'Chronic Sun Exposure', 'Poor Oral Hygiene',
                      'Diet (Fruits & Vegetables Intake)', 'Family History of Cancer',
                      'Compromised Immune System', 'Oral Lesions', 'Unexplained Bleeding',
                      'Difficulty Swallowing', 'White or Red Patches in Mouth',
                      'Early Diagnosis', 'Country']

# Prepare features and target
X = df.drop(['ID', 'Oral Cancer (Diagnosis)'] + post_diagnosis_features, axis=1)
y = df['Oral Cancer (Diagnosis)']

print(f"\nFeatures used for prediction: {list(X.columns)}")

# Split the data with stratification
X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.125, random_state=42, stratify=y_temp)

print(f"\nTraining set: {X_train.shape[0]} samples")
print(f"Validation set: {X_val.shape[0]} samples")
print(f"Testing set: {X_test.shape[0]} samples")

# Save testing set to CSV
test_data = pd.concat([X_test, y_test], axis=1)
test_data.to_csv('test_set.csv', index=False)

# Define preprocessing steps
numeric_features = ['Age']
categorical_features = categorical_columns

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numeric_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ])

# Feature selection using RFE with logistic regression
print("\nPerforming feature selection...")

# Hyperparameter tuning with GridSearchCV
print("\nPerforming hyperparameter tuning...")

# Define the pipeline with feature selection
pipeline = ImbPipeline([
    ('preprocessor', preprocessor),
    ('smote', SMOTE(random_state=42)),
    ('feature_selection', SelectFromModel(estimator=LogisticRegression(C=0.1, random_state=42), 
                                         max_features=15)),  # Limit to top 15 features
    ('model', LogisticRegression(random_state=42, max_iter=2000))
])

# Define parameter grid for hyperparameter tuning
param_grid = {
    'model__C': [0.001, 0.01, 0.1, 1, 10, 100],
    'model__penalty': ['l1', 'l2'],
    'model__solver': ['liblinear', 'saga'],
    'model__class_weight': ['balanced', None]
}

# Set up cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Perform grid search
grid_search = GridSearchCV(
    pipeline, 
    param_grid, 
    cv=cv, 
    scoring='roc_auc',
    n_jobs=-1,
    verbose=1
)

grid_search.fit(X_train, y_train)

# Print best parameters
print("\nBest parameters:")
print(grid_search.best_params_)
print(f"Best cross-validation score: {grid_search.best_score_:.4f}")

# Get the best model
best_model = grid_search.best_estimator_

# Evaluate on validation set
val_pred = best_model.predict(X_val)
val_pred_proba = best_model.predict_proba(X_val)[:, 1]

print("\nValidation Set Performance:")
print(f"Accuracy: {accuracy_score(y_val, val_pred):.4f}")
print(f"ROC AUC: {roc_auc_score(y_val, val_pred_proba):.4f}")
print("\nClassification Report:")
print(classification_report(y_val, val_pred))
print("\nConfusion Matrix:")
print(confusion_matrix(y_val, val_pred))

# Evaluate on test set
test_pred = best_model.predict(X_test)
test_pred_proba = best_model.predict_proba(X_test)[:, 1]

print("\nTest Set Performance:")
print(f"Accuracy: {accuracy_score(y_test, test_pred):.4f}")
print(f"ROC AUC: {roc_auc_score(y_test, test_pred_proba):.4f}")
print("\nClassification Report:")
print(classification_report(y_test, test_pred))
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, test_pred))

# Plot confusion matrix for test set
plt.figure(figsize=(8, 6))
sns.heatmap(confusion_matrix(y_test, test_pred), annot=True, fmt='d', cmap='Blues')
plt.title('Confusion Matrix (Test Set)')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.savefig('improved_confusion_matrix.png')
plt.close()

# Plot ROC curve
from sklearn.metrics import roc_curve
fpr, tpr, _ = roc_curve(y_test, test_pred_proba, pos_label='Yes')
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, label=f'ROC Curve (AUC = {roc_auc_score(y_test, test_pred_proba):.4f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve (Test Set)')
plt.legend()
plt.savefig('improved_roc_curve.png')
plt.close()

# Plot Precision-Recall curve
precision, recall, _ = precision_recall_curve(y_test, test_pred_proba, pos_label='Yes')
avg_precision = average_precision_score(y_test == 'Yes', test_pred_proba)
plt.figure(figsize=(8, 6))
plt.plot(recall, precision, label=f'PR Curve (AP = {avg_precision:.4f})')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve (Test Set)')
plt.legend()
plt.savefig('precision_recall_curve.png')
plt.close()

# Get feature importances from the best model
# We need to get the actual feature names that were selected by SelectFromModel
# First, get all feature names after preprocessing
all_feature_names = (numeric_features + 
                list(best_model.named_steps['preprocessor']
                    .named_transformers_['cat']
                    .get_feature_names_out(categorical_features)))

# Get the feature selection step
feature_selector = best_model.named_steps['feature_selection']

# Get the mask of selected features
selected_mask = feature_selector.get_support()

# Get the names of selected features
selected_feature_names = [all_feature_names[i] for i in range(len(all_feature_names)) if selected_mask[i]]

# For logistic regression, we use coef_ instead of feature_importances_
# Take absolute values since coefficients can be negative
coefs = np.abs(best_model.named_steps['model'].coef_[0])

# Create feature importance DataFrame with proper feature names
feature_importance = pd.DataFrame({
    'Feature': selected_feature_names,
    'Importance': coefs
}).sort_values('Importance', ascending=False)

print("\nTop Feature Importance:")
print(feature_importance)

# Plot features
plt.figure(figsize=(12, 8))
sns.barplot(x='Importance', y='Feature', data=feature_importance)
plt.title('Feature Importance')
plt.tight_layout()
plt.savefig('improved_feature_importance.png')
plt.close()

# Save the model
joblib.dump(best_model, 'improved_oral_cancer_model.pkl')
print("\nImproved model saved as 'improved_oral_cancer_model.pkl'")

# Return to original stdout
sys.stdout = sys.__stdout__
print("All results saved to improved_model_results.txt")